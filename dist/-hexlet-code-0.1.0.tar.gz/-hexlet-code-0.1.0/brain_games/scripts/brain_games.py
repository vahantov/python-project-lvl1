#!/usr/bin/env python

# if __name__ == '__main__':
#     print('Welcome to the Brain Games!')

def greet(who):
    print('Hello, {}!'.format(who))

def main():
    greet('Bob')
    greet('Ann')

if __name__ == '__main__':
    main()